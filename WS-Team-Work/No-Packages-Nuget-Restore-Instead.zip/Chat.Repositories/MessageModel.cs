﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Chat.Repositories
{
    public class MessageModel
    {
        public int Id { get; set; }

        public string Content { get; set; }
    }
}
