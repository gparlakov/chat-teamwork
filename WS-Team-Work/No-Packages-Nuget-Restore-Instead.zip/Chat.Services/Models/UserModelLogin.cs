﻿
namespace Chat.Services.Models
{
    public class UserModelLogin
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}